 const keyRemap = {
    'a': 'u', 'c': 'v', 'd': 'a', 'e': 'o', 'f': 'i', 'g': '.', 'h': 'g',
    'i': 'h', 'j': 't', 'k': 'n', 'l': 'k', 'n': 'd', 'o': 'b', 'q': 'f',
    'r': 'y', 's': 'e', 't': ',', 'u': 'r', 'v': 'w', 'x': 'c', 'y': 'z',
    'z': 'x', ',': 'q', '.': 'l', '/': 'j', ';': 's'
  };

  const words = [
    { kana: "さかな", roma: "sakana" },
    { kana: "たこ", roma: "tako" },
    { kana: "いぬ", roma: "inu" },
    { kana: "ねこ", roma: "neko" },
    { kana: "うま", roma: "uma" },
    { kana: "とり", roma: "tori" },
    { kana: "かめ", roma: "kame" },
    { kana: "しか", roma: "sika" },
    { kana: "くま", roma: "kuma" },
    { kana: "ぞう", roma: "zou" },
    { kana: "きつね", roma: "kitune" },
    { kana: "りす", roma: "risu" },
    { kana: "へび", roma: "hebi" },
    { kana: "あり", roma: "ari" },
    { kana: "かに", roma: "kani" },
    { kana: "えび", roma: "ebi" },
    { kana: "うし", roma: "usi" },
    { kana: "ひつじ", roma: "hituzi" },
    { kana: "とんぼ", roma: "tonbo" },
    { kana: "ちょう", roma: "tyou" },
    { kana: "すいか", roma: "suika" },
    { kana: "りんご", roma: "ringo" },
    { kana: "みかん", roma: "mikan" },
    { kana: "もも", roma: "momo" },
    { kana: "いちご", roma: "itigo" },
    { kana: "なし", roma: "nasi" },
    { kana: "ぶどう", roma: "budou" },
    { kana: "ばなな", roma: "banana" },
    { kana: "さくらんぼ", roma: "sakuranbo" },
    { kana: "めろん", roma: "meron" },
    { kana: "じゃんけん", roma: "janken" },
    { kana: "じゅぎょう", roma: "jugyou" },
    { kana: "じょおう", roma: "joou" },
    { kana: "じょうほう", roma: "jouhou" },
    { kana: "じゅうりょう", roma: "juuryou" },
    { kana: "ジャンル", roma: "janru" },
    { kana: "じしょ", roma: "zisyo" },
    { kana: "じょうしき", roma: "jousiki" },
    { kana: "じゅうどう", roma: "juudou" },
    { kana: "じょせい", roma: "josei" }
  ];

  let current = {};
  let score = 0;
  let timeLeft = 60;
  let timer = null;
  let gameActive = false;
  let timerStarted = false;
  let inputPos = 0;

  const kanaEl = document.getElementById("kana");
  const romajiEl = document.getElementById("romaji");
  const typedEl = document.getElementById("typed");
  const resultEl = document.getElementById("result");
  const scoreEl = document.getElementById("score");
  const timerEl = document.getElementById("timer");
  const retryBtn = document.getElementById("retry");

  function pickWord() {
    current = words[Math.floor(Math.random() * words.length)];
    kanaEl.textContent = current.kana;
    romajiEl.textContent = current.roma;
    typedEl.innerHTML = "";
    inputPos = 0;
  }

  function startTimer() {
    if (!timerStarted) {
      timerStarted = true;
      gameActive = true;
      timer = setInterval(() => {
        timeLeft--;
        timerEl.textContent = `残り時間: ${timeLeft}秒`;
        if (timeLeft <= 0) {
          clearInterval(timer);
          gameActive = false;
          resultEl.textContent = "時間切れ";
          retryBtn.style.display = "inline-block";
        }
      }, 1000);
    }
  }

  function startGame() {
    score = 0;
    timeLeft = 60;
    timerStarted = false;
    gameActive = false;
    scoreEl.textContent = `スコア: ${score}`;
    timerEl.textContent = `残り時間: ${timeLeft}秒`;
    resultEl.textContent = "";
    retryBtn.style.display = "none";
    pickWord();
    typedEl.innerHTML = "";
    inputPos = 0;
  }

  function getRemappedKey(e) {
    const k = e.key.toLowerCase();
    if (keyRemap.hasOwnProperty(k)) {
      return keyRemap[k];
    }
    if (k.length === 1 && k.match(/[a-z,.;\/]/)) {
      return k;
    }
    return null;
  }

  window.addEventListener("keydown", e => {
    if (!timerStarted) {
      // 最初の有効入力でタイマー開始
      if (e.key.length === 1 || e.key === "Backspace") {
        startTimer();
      }
    }

    if (!gameActive) return;

    if (["Shift", "Control", "Alt", "CapsLock", "Tab", "Meta"].includes(e.key)) return;

    e.preventDefault();

    if (e.key === "Backspace") {
      if (inputPos > 0) {
        inputPos--;
        typedEl.innerHTML = typedEl.innerHTML.slice(0, -1);
      }
      return;
    }

    const remapped = getRemappedKey(e);
    if (!remapped) return;

    const expectedChar = current.roma[inputPos];
    if (!expectedChar) return;

    if (remapped === expectedChar) {
      typedEl.innerHTML += `<span style="color:#0e6e28">${remapped}</span>`;
      inputPos++;
      if (inputPos === current.roma.length) {
        score++;
        scoreEl.textContent = `スコア: ${score}`;
        resultEl.textContent = "次";
        setTimeout(() => {
          resultEl.textContent = "";
          pickWord();
        }, 500);
      }
    } else {
      resultEl.textContent = "ミス";
      typedEl.innerHTML += `<span style="color:red">${remapped}</span>`;
      setTimeout(() => { resultEl.textContent = ""; }, 800);
    }
  });

  retryBtn.addEventListener("click", () => {
    startGame();
  });

  window.onload = () => {
    startGame();
  };